
<?php
// params for conect to database sttopingpellas
define ('DB_HOST', 'localhost');
define ('DB_USUARIO','daw');
define ('DB_CONTRA','9609');
//define ('DB_NOMBRE','bdmusica');
define ('DB_NOMBRE','stoppingpellas');
define ('DB_CHARSET','UTF8');
?>
